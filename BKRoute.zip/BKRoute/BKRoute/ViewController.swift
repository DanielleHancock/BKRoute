//
//  ViewController.swift
//  BKRoute
//
//  Created by csc332 on 3/4/16.
//  Copyright © 2016 csc332. All rights reserved.
//
// Sources:
// http://www.johnmullins.co/blog/2014/08/14/location-tracker-with-maps/
// http://iostechsolutions.blogspot.com/2014/11/swift-take-pictures-and-save-to-camera.html
// http://stackoverflow.com/questions/27349612/how-do-i-add-pins-annotations-with-xcode-6-swift

import UIKit
import MapKit
import CoreLocation
import MobileCoreServices

class ViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UIAlertViewDelegate {
    
    @IBOutlet weak var theMap: MKMapView!
    
    var manager:CLLocationManager!
    var cameraUI: UIImagePickerController! = UIImagePickerController()
    var myLocations: [CLLocation] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Setup our Location Manager
        manager = CLLocationManager()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyBest
        manager.requestAlwaysAuthorization()
        //manager.startUpdatingLocation()
        
        //Setup our Map View
        theMap.delegate = self
        theMap.mapType = MKMapType.Satellite
        theMap.showsUserLocation = true
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func locationManager(manager:CLLocationManager, didUpdateLocations locations:[CLLocation]) {
        myLocations.append(locations[0] as CLLocation)
        
        let spanX = 0.007
        let spanY = 0.007
        let newRegion = MKCoordinateRegion(center: theMap.userLocation.coordinate, span: MKCoordinateSpanMake(spanX, spanY))
        theMap.setRegion(newRegion, animated: true)
        
        if (myLocations.count > 1){
            let sourceIndex = myLocations.count - 1
            let destinationIndex = myLocations.count - 2
            
            let c1 = myLocations[sourceIndex].coordinate
            let c2 = myLocations[destinationIndex].coordinate
            var a = [c1, c2]
            let polyline = MKPolyline(coordinates: &a, count: a.count)
            theMap.addOverlay(polyline)
        }
    }
    
    func mapView(mapView: MKMapView!, rendererForOverlay overlay: MKOverlay!) -> MKOverlayRenderer! {
        
        if overlay is MKPolyline {
            let polylineRenderer = MKPolylineRenderer(overlay: overlay)
            polylineRenderer.strokeColor = UIColor.blueColor()
            polylineRenderer.lineWidth = 4
            return polylineRenderer
        }
        return nil
    }
    
    // start drawing route
    @IBAction func startButton(sender: UIButton) {
        myLocations = []
        manager.startUpdatingLocation()
    }
    
    // stop drawing route
    @IBAction func stop(sender: UIButton) {
        manager.stopUpdatingLocation()
    }
    
    // delete all routes displayed on the map
    @IBAction func clearButton(sender: UIButton) {
        let overlays = theMap.overlays
        theMap.removeOverlays(overlays)
    }
    
    @IBAction func takePhoto(sender: UIButton) {
        self.presentCamera()
        
        // drop a pin
        self.theMap.delegate = self
        let coordinate = theMap.userLocation.coordinate
        let dropPin = MKPointAnnotation()
        dropPin.coordinate = coordinate
        dropPin.title = "Photo Taken Here"
        dropPin.subtitle = String(format: "%.3f", theMap.userLocation.coordinate.latitude) + ", " + String(format: "%.3f", theMap.userLocation.coordinate.longitude)
        theMap.addAnnotation(dropPin)
    }
    
    func presentCamera()
    {
        
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.Camera)
        {
            print("Button capture")
            
            cameraUI = UIImagePickerController()
            cameraUI.delegate = self
            cameraUI.sourceType = UIImagePickerControllerSourceType.Camera;
            cameraUI.mediaTypes = [kUTTypeImage as String]
            cameraUI.allowsEditing = false
            
            self.presentViewController(cameraUI, animated: true, completion: nil)
        }
        else
        {
            // error msg
        }
    }
    
    //Mark- UIImagePickerController Delegate
    
    func imagePickerControllerDidCancel(picker:UIImagePickerController)
    {
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    
    
    
    
    func imagePickerController(picker:UIImagePickerController, didFinishPickingMediaWithInfo info:[String: AnyObject])
    {
        if(picker.sourceType == UIImagePickerControllerSourceType.Camera)
        {
            // Access the uncropped image from info dictionary
            //var imageToSave: UIImage = info.objectForKey(UIImagePickerControllerOriginalImage) as! UIImage
            let imageToSave: UIImage = info[UIImagePickerControllerOriginalImage] as! UIImage //same but with different way
            
            UIImageWriteToSavedPhotosAlbum(imageToSave, nil, nil, nil)
            
            self.savedImageAlert()
            self.dismissViewControllerAnimated(true, completion: nil)
            
        }
        
    }
    
    
    func savedImageAlert()
    {
        var alert:UIAlertView = UIAlertView()
        alert.title = "Saved!"
        alert.message = "Your picture was saved to Camera Roll"
        alert.delegate = self
        alert.addButtonWithTitle("Ok")
        alert.show()
    }
    

}

